import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertConversationSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes for conversations
  app.post("/api/conversations", async (req: Request, res: Response) => {
    try {
      const data = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(data);
      res.status(201).json(conversation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create conversation" });
    }
  });

  app.get("/api/conversations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const conversation = await storage.getConversation(id);
      
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }
      
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ error: "Failed to get conversation" });
    }
  });

  // API Routes for messages
  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const data = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(data);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  app.get("/api/conversations/:id/messages", async (req: Request, res: Response) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getMessagesForConversation(conversationId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  // API route for sending messages to the chatbot
  app.post("/api/chatbot", async (req: Request, res: Response) => {
    try {
      const { message, conversationId } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      let convoId = conversationId;
      
      // Create a new conversation if none exists
      if (!convoId) {
        const conversation = await storage.createConversation({});
        convoId = conversation.id;
      }
      
      // Save the user message
      await storage.createMessage({
        conversationId: convoId,
        sender: "user",
        text: message
      });
      
      // Send to Rasa and get response
      try {
        // Add more logging to debug the issue
        console.log("Sending message to Rasa:", message);
        
        const rasaResponse = await fetch("https://rasa-for-beginners-production.up.railway.app/webhooks/rest/webhook", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ sender: "user", message })
        });
        
        // Log the status and response from Rasa
        console.log("Rasa response status:", rasaResponse.status);
        
        const data = await rasaResponse.json();
        console.log("Rasa response data:", JSON.stringify(data));
        
        if (Array.isArray(data) && data.length > 0) {
          // Save bot responses to database
          const savedResponses = [];
          
          for (const msg of data) {
            const savedMessage = await storage.createMessage({
              conversationId: convoId,
              sender: "bot",
              text: msg.text
            });
            
            savedResponses.push(savedMessage);
          }
          
          return res.json({
            conversationId: convoId,
            messages: savedResponses
          });
        } else {
          // If we get an empty array from Rasa, provide a default response
          const defaultMessage = await storage.createMessage({
            conversationId: convoId,
            sender: "bot",
            text: "I understand you're experiencing some health concerns. Can you provide more details about your symptoms, such as when they started and if you have any other symptoms?"
          });
          
          return res.json({
            conversationId: convoId,
            messages: [defaultMessage]
          });
        }
        
      } catch (error) {
        console.error("Rasa Error:", error);
        
        // Save error message
        const errorMessage = await storage.createMessage({
          conversationId: convoId,
          sender: "bot",
          text: "Sorry, I'm having trouble connecting to the GP assistant. Please try again later."
        });
        
        return res.json({
          conversationId: convoId,
          messages: [errorMessage]
        });
      }
      
    } catch (error) {
      console.error("API Error:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

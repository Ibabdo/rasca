// Define common types for the application

export interface ChatMessage {
  sender: "user" | "bot";
  text: string;
}

export interface ApiMessage {
  id: number;
  conversationId: number;
  sender: "user" | "bot";
  text: string;
  createdAt: string;
  metadata: any;
}

export interface ApiResponse {
  conversationId: number;
  messages: ApiMessage[];
}
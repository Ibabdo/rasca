import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { ChatMessage, ApiMessage, ApiResponse } from '../types';

interface UseChatbotReturn {
  messages: ChatMessage[];
  input: string;
  isLoading: boolean;
  conversationId: number | null;
  setInput: (input: string) => void;
  sendMessage: () => Promise<void>;
}

export const useChatbot = (): UseChatbotReturn => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { sender: 'bot', text: "Hello! I'm your GP assistant. What would you like to discuss today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [conversationId, setConversationId] = useState<number | null>(null);

  // Mutation for sending messages
  const sendMessageMutation = useMutation<ApiResponse, Error, string>({
    mutationFn: async (message: string) => {
      return apiRequest<ApiResponse>('/api/chatbot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          message,
          conversationId 
        })
      });
    },
    onSuccess: (data) => {
      // Update conversation ID if it's a new conversation
      if (data.conversationId && !conversationId) {
        setConversationId(data.conversationId);
      }
      
      // Add bot responses to messages
      if (Array.isArray(data.messages)) {
        data.messages.forEach((msg: ApiMessage) => {
          setMessages((prev) => [...prev, { 
            sender: msg.sender, 
            text: msg.text 
          }]);
        });
      }
    }
  });

  const sendMessage = async (): Promise<void> => {
    if (!input.trim()) return;

    // Add user message to UI immediately
    const userMessage: ChatMessage = { sender: 'user', text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Send to our backend API instead of directly to Rasa
      await sendMessageMutation.mutateAsync(input);
    } catch (error) {
      // Add error message
      setMessages((prev) => [
        ...prev,
        { 
          sender: 'bot', 
          text: "Sorry, I'm having trouble connecting to the GP assistant. Please try again later." 
        }
      ]);
      console.error('Chat API Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    messages,
    input,
    isLoading,
    conversationId,
    setInput,
    sendMessage,
  };
};

import React from "react";
import { User, Heart } from "lucide-react";
import { ChatMessage } from "../../types";

interface ChatBubbleProps {
  message: ChatMessage;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.sender === "user";
  
  // Process text to handle bullet points in bot messages
  const processText = (text: string) => {
    // Check if the message contains bullet points indicated by line breaks and dashes or asterisks
    if (message.sender === "bot" && 
        (text.includes("\n- ") || text.includes("\n* ") || text.includes("\n• "))) {
      
      const parts = text.split(/\n([- *•] )/);
      if (parts.length > 1) {
        // Extract the initial text before the bullet points
        const initialText = parts[0];
        const items: string[] = [];
        
        // Collect bullet point items
        for (let i = 1; i < parts.length; i += 2) {
          if (i + 1 < parts.length) {
            items.push(parts[i + 1]);
          }
        }
        
        return (
          <>
            <p>{initialText}</p>
            {items.length > 0 && (
              <ul className="list-disc ml-5 mt-2 space-y-1">
                {items.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            )}
          </>
        );
      }
    }
    
    return <p>{text}</p>;
  };

  if (isUser) {
    return (
      <div className="flex items-start justify-end space-x-2 ml-auto max-w-[85%]">
        <div className="bg-primary-600 text-white rounded-lg rounded-tr-none p-3 text-sm md:text-base shadow-sm">
          {processText(message.text)}
        </div>
        <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center flex-shrink-0">
          <User className="h-4 w-4 text-neutral-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-2 max-w-[85%]">
      <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
        <Heart className="h-4 w-4 text-primary-600" />
      </div>
      <div className="bg-neutral-100 rounded-lg rounded-tl-none p-3 text-sm md:text-base shadow-sm">
        {processText(message.text)}
      </div>
    </div>
  );
};

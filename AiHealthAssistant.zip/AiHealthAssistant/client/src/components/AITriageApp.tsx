import { useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mic, Send, Paperclip, AlertTriangle } from "lucide-react";
import { ChatBubble } from "@/components/ui/ChatBubble";
import { useChatbot } from "@/hooks/useChatbot";
import { ChatMessage } from "../types";

export default function AITriageApp() {
  const { messages, input, isLoading, setInput, sendMessage, conversationId } = useChatbot();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-neutral-100">
      {/* Header Section */}
      <header className="w-full bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
              <path d="M12 5 9.04 7.96a3 3 0 0 0 0 4.24l2.83 2.83" />
            </svg>
            <h1 className="text-lg md:text-xl font-bold text-neutral-800">GP Assistant</h1>
          </div>
          <div className="flex items-center">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
              Active
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-3xl flex-1 mx-auto p-4">
        {/* Information Card */}
        <Card className="mb-4 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400" 
            alt="Medical consultation with healthcare professional" 
            className="w-full h-40 object-cover object-center" 
          />
          <CardContent className="p-4">
            <h2 className="text-xl md:text-2xl font-bold text-neutral-800 mb-2">Speak to Your GP Assistant</h2>
            <p className="text-neutral-600 text-sm md:text-base">
              I'm here to help assess your symptoms and provide medical guidance. Please describe what brings you here today.
            </p>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <Card className="overflow-hidden">
          {/* Messages Container */}
          <div className="h-[400px] overflow-y-auto p-4 space-y-4">
            {messages.map((msg, i) => (
              <ChatBubble key={i} message={msg} />
            ))}
            {isLoading && (
              <div className="flex items-start space-x-2 max-w-[85%]">
                <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                    <path d="M12 5 9.04 7.96a3 3 0 0 0 0 4.24l2.83 2.83" />
                  </svg>
                </div>
                <div className="bg-neutral-100 rounded-lg rounded-tl-none p-3 text-sm md:text-base shadow-sm">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay: "0.2s"}}></div>
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay: "0.4s"}}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-neutral-200 p-3">
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Paperclip className="h-5 w-5 text-neutral-500" />
              </Button>
              <div className="flex-1 relative">
                <Input 
                  type="text" 
                  placeholder="Type your message or question..." 
                  className="w-full py-2.5 px-4 bg-neutral-100 rounded-full text-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary-500 text-sm md:text-base"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                />
              </div>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Mic className="h-5 w-5 text-neutral-600" />
              </Button>
              <Button 
                onClick={sendMessage} 
                className="rounded-full bg-primary-600 hover:bg-primary-700"
                size="icon"
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Medical Disclaimer */}
          <div className="bg-neutral-50 border-t border-neutral-200 p-3">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-neutral-600">
                This chatbot follows UK GP triage protocols. It does not replace professional medical advice. In an emergency, call 999 or go to your nearest A&E.
              </p>
            </div>
          </div>
        </Card>

        {/* Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {/* Healthcare Providers Card */}
          <Card className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 9h-5V4H9v5H4v6h5v5h6v-5h5V9z" />
                </svg>
              </div>
              <h3 className="font-bold text-neutral-800">Healthcare Providers</h3>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300" 
              alt="Healthcare professional in clinical setting" 
              className="w-full h-32 object-cover rounded-lg mb-3" 
            />
            <p className="text-sm text-neutral-600">
              Connect with trusted healthcare professionals for follow-up consultations when recommended.
            </p>
          </Card>

          {/* Medical Resources Card */}
          <Card className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
                </svg>
              </div>
              <h3 className="font-bold text-neutral-800">Medical Resources</h3>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300" 
              alt="Patient consulting with a doctor about health information" 
              className="w-full h-32 object-cover rounded-lg mb-3" 
            />
            <p className="text-sm text-neutral-600">
              Access NHS-approved information about conditions, treatments, and healthy living advice.
            </p>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full bg-white border-t border-neutral-200 py-4 mt-6">
        <div className="max-w-3xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <div className="flex items-center justify-center md:justify-start space-x-2 mb-1">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                <path d="M12 5 9.04 7.96a3 3 0 0 0 0 4.24l2.83 2.83" />
              </svg>
              <span className="font-bold text-neutral-800">GP Assistant</span>
            </div>
            <p className="text-xs text-neutral-500">© 2023 NHS Digital. All rights reserved.</p>
          </div>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-sm text-neutral-600 hover:text-primary-600 transition-colors">Privacy</a>
            <a href="#" className="text-sm text-neutral-600 hover:text-primary-600 transition-colors">Terms</a>
            <a href="#" className="text-sm text-neutral-600 hover:text-primary-600 transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

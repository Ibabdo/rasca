import AITriageApp from "@/components/AITriageApp";

export default function Home() {
  return <AITriageApp />;
}
